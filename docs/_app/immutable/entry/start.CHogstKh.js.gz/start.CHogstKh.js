import{a as t}from"../chunks/entry.DG5B1Y6W.js";export{t as start};
